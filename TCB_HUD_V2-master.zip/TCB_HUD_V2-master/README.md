<p align="center">
  <img src="https://www.thecodingbeast.com/img/products/hudv2.png" alt="TCB - HUD V2"/>
  <h1 align="center">:no_entry: THIS PROJECT IS DEPRECATED :no_entry:</h1>
</p>

**This project may not work as expected and is only here for legacy purposes.** It's no longer supported and should not be relied upon unless you are able to solve issues on your own. Feel free to fork the repo for future use.

**License:** [Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0)](http://creativecommons.org/licenses/by-nc-sa/4.0/)
