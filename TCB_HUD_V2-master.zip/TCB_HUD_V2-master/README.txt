/*---------------------------------------------------------------------------
	
	Creator: TheCodingBeast - TheCodingBeast.com
	This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License. 
	To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/4.0/
	
---------------------------------------------------------------------------*/


STEP 1
-------
Upload the 'resource' folder to the main garry's mod directory 'garrysmod/'.


STEP 2
-------
Upload the 'TCB_HUD_V2' folder to the 'darkrp_modules' folder in 'garrysmod/addons/darkrpmodification/lua/'.


FIX 1
-------
If you still see the old hud then open the 'disabled_defaults.lua' file in 'garrysmod\addons\darkrpmodification\lua\darkrp_config'.
Find '["hud"]' on around line 30 and set the value to 'true'.